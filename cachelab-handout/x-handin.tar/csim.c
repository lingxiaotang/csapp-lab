#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include<getopt.h>

//here defines some global datas
//S is the number of sets
uint64_t s=0,S=0;
//E is the number of lines per set;
uint64_t E=0;
//b is the number of block bits and B is the block size
uint64_t b=0,B=0;
//fileName is the name of the input file
char fileName[20];


//parse command line parameters and save them to local variables
void parseCommandLine(int argc, char *argv[]);


int main(int argc,char *argv[]){
    parseCommandLine(argc,argv);
    printf("s=%lu,S=%lu\n",s,S);
    printf("E=%lu\n",E);
    printf("b=%lu,B=%lu\n",b,B);
    puts(fileName);
}


void parseCommandLine(int argc, char *argv[])
{
    int ch = 0;
    char * helpMessage="./csim-ref: Missing required command line argument\n"\
    "Usage: ./csim-ref [-hv] -s <num> -E <num> -b <num> -t <file>\n"\
    "Options:\n"\
    "-h         Print this help message.\n"\
    "-v         Optional verbose flag.\n"\
    "-s <num>   Number of set index bits.\n"\
    "-E <num>   Number of lines per set.\n"\
    "-b <num>   Number of block offset bits.\n"\
    "-t <file>  Trace file.\n"\

    "Examples:\n"\
    "linux>  ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace\n"\
    "linux>  ./csim-ref -v -s 8 -E 2 -b 4 -t traces/yi.trace\n";
    opterr=0;
    while((ch=getopt(argc,argv,"h::v::s:E:b:t:"))!=-1){
        switch (ch)
        {
            case 'h':
                puts(helpMessage);
                exit(0);
                break;
            case 'v':
                puts(helpMessage);
                exit(0);
                break;
            case 's':
                s=atol(optarg);
                S=pow(2,s);
                break;
            case 'E':
                E=atol(optarg);
                break;
            case 'b':
                b=atol(optarg);
                B=pow(2,b);
                break;
            case 't':
                strcpy(fileName,optarg);
                break;
            case '?'://some error occurs
                puts("error in the parameters!Please reenter the parameters!");
            default:
                puts(helpMessage);
                exit(0);
                break;
        }
    }
}

